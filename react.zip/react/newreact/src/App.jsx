
import './App.css'
import Footer from './componets/Footer'
import Header from './componets/Header'
import Mainsection from './componets/MainSection'
import SideBar from './componets/Sidebar'

function App() {

  return (
    <>
    <Header/>
    <div style={{display:'flex'}}>
      <SideBar/>
      <Mainsection/>
    </div>
    <Footer/>

    </>
  )
}

export default App
