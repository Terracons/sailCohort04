

function Header(){
    return (
        <div className="Header" style={{background:"white", height:"50px",  width: "1280px"}} >
            <h2>Header</h2>
            </div>
        
    )
}

export default Header;