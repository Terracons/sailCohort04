function Footer(){
    return (
        <div className="Header" style={{background:"white", height:"200px",  width: "1280px"}} >
        <h2>Footer</h2>
        </div>
    )
}

export default Footer;