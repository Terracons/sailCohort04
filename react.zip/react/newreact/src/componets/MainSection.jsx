function Mainsection(){
    return (
        <div className="Header" style={{background:"white", height:"400px",  width: "800px", margin:"10px"}} >
<h2>Mainsection</h2>
        </div>
        
    )
}

export default Mainsection;