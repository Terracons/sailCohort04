function SideBar(){
    return (
        <div className="Header" style={{background:"white", height:"400px",  width: "280px", margin:"10px"}} >
<h2>SideBar</h2>
        </div>
        
    )
}

export default SideBar;